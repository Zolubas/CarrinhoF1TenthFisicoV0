#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from slam_toolbox.srv import SaveMap

class SaveSlamMapOnce(Node):
    def __init__(self):
        super().__init__('save_slam_map_once')

        # ✅ This must be a valid path WITHOUT extension
        self.map_name = '/home/lca/icra25/icra25Qualify_ws/src/ebva_mapless_control/ebva_mapless_control/slam_saved_map'

        self.cli = self.create_client(SaveMap, '/slam_toolbox/save_map')
        self.get_logger().info('Waiting for /slam_toolbox/save_map service...')
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting again...')

        self.req = SaveMap.Request()
        self.req.name = str(self.map_name)  # ✅ This must be a plain string

        self.future = self.cli.call_async(self.req)
        self.get_logger().info(f'Sent map save request to: {self.map_name}')
        self.timer = self.create_timer(0.1, self.check_response)

    def check_response(self):
        if self.future.done():
            try:
                response = self.future.result()
                if response.success:
                    self.get_logger().info('✅ Map saved successfully!')
                else:
                    self.get_logger().error('❌ Map saving failed.')
            except Exception as e:
                self.get_logger().error(f'Service call failed: {e}')
            finally:
                self.timer.cancel()
                rclpy.shutdown()

def main():
    rclpy.init()
    node = SaveSlamMapOnce()
    rclpy.spin(node)

if __name__ == '__main__':
    main()
