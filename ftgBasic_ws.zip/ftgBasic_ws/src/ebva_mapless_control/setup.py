from setuptools import setup

package_name = 'ebva_mapless_control'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='lca',
    maintainer_email='lca@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
        'EBVAUSPQualifier = ebva_mapless_control.EBVAUSPQualifier:main',
        'escuderia_waypoints_getter = ebva_mapless_control.escuderia_waypoints_getter:main',
        'save_slam_map_once = ebva_mapless_control.save_slam_map_once:main',
        ],
    },
)
