import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from std_msgs.msg import Float64
import serial

class Autodrive2Vehicle(Node):
    def __init__(self):
        super().__init__('rc_reader_node')

        # Publishers for throttle and steering
        self.throttle_pub = self.create_publisher(Float64, '/commands/motor/speed', 10)
        self.steering_pub = self.create_publisher(Float64, '/commands/servo/position', 10)
        
        # Subscribers for throttle and steering coming from autodrive simulation environment
        self.steering_sub = self.create_subscription(
            Float32,
            '/autodrive/f1tenth_1/steering_command',
            self.steering_callback,
            10
        )

        self.throttle_sub = self.create_subscription(
            Float32,
            '/autodrive/f1tenth_1/throttle_command',
            self.throttle_callback,
            10
        )

        # Class atributes
        self.steering_autodrive = Float32()
        self.throttle_autodrive = Float32()
        self.radio_tolerance=100

        # Initializing atributes
        self.steering_autodrive.data = 0.0
        self.throttle_autodrive.data = 0.0
        
        # Scaling factors
        self.steering_scaling_factor=1
        self.throttle_scaling_factor= 3000/0.12
        self.steering_bias = 0.5
        self.throttle_min = 1500.0
        
        
        # Open serial port (adjust to your Arduino's port)
        #self.ser = serial.Serial('/dev/ttyACM1', 115200, timeout=1)
        self.ser = serial.Serial('/dev/arduino_rc', 115200, timeout=1)

        # Timer for periodic read
        self.timer = self.create_timer(0.01, self.timer_callback)  # 100 Hz

    def steering_callback(self, msg):
        self.steering_autodrive = msg
        self.steering_autodrive.data = self.steering_scaling_factor*self.steering_autodrive.data

    def throttle_callback(self, msg):
        self.throttle_autodrive = msg
        
        if self.throttle_autodrive.data < 0.016:
            self.throttle_autodrive.data=0.0
        else:
            self.throttle_autodrive.data = 14563.1068*self.throttle_autodrive.data+1252.4272 + 1000.0
        
        #self.throttle_autodrive.data = self.throttle_scaling_factor*self.throttle_autodrive.data



    def map_value(self, value, in_min, in_max, out_min, out_max):
        """Linearly map value from one range to another."""
        return (value - in_min) * (out_max - out_min) / (in_max - in_min) + out_min

    def timer_callback(self):
        if self.ser.in_waiting > 0:
            try:
                #line = self.ser.readline().decode('utf-8').strip()
                # Handling serial data while ignoring errors to avoid crashing the code
                line = self.ser.readline().decode('utf-8', errors='ignore').strip()
                parts = line.split(',')
                if len(parts) == 2:
                    ch1 = float(parts[0])  # Throttle channel (1000–2000)
                    ch2 = float(parts[1])  # Steering channel (1000–2000)

                    if abs(ch1-1500)>self.radio_tolerance or abs(ch2-1500)>self.radio_tolerance:

                        # Map RC channels to commands
                        throttle_cmd = self.map_value(ch1, 1000, 2000, -4500.0, 4500.0)
                        steering_cmd = self.map_value(ch2, 1100, 1900, 0.15, 0.85)

                        # Publish  radio messages
                        throttle_msg = Float64()
                        steering_msg = Float64()

                        throttle_msg.data = throttle_cmd
                        steering_msg.data = steering_cmd

                        self.throttle_pub.publish(throttle_msg)
                        self.steering_pub.publish(steering_msg)

                        self.get_logger().info(
                            f"RC: Ch1={ch1} → Throttle={throttle_cmd:.1f} rpm, "
                            f"Ch2={ch2} → Steering={steering_cmd:.3f} rad"
                        )

                    else:

                        # Publish autodrive_control messages
                        throttle_msg = Float64()
                        steering_msg = Float64()

                        throttle_msg.data = float(self.throttle_autodrive.data)
                        #steering_msg.data = -float(self.steering_autodrive.data)+self.steering_bias
                        ##steering_msg.data = float(-0.35*float(self.steering_autodrive.data)+float(self.steering_bias)) #assuming that FTG sends commands from -60º,+60º -> -1,1 rad
                        #steering_msg.data = self.steering_autodrive.data
                        steering_msg.data=self.map_value(self.steering_autodrive.data, 0.35, -0.35, 0.15, 0.85) #rad

                        self.throttle_pub.publish(throttle_msg)
                        self.steering_pub.publish(steering_msg)

                        self.get_logger().info(
                            f"AutodriveControl: Throttle={throttle_msg.data:.1f} rpm, "
                            f"Steering={steering_msg.data:.3f} rad, "
                            f"Steering autodrive={self.steering_autodrive.data:.3f} º"
                        )


            except ValueError:
                pass  # skip invalid lines

def main(args=None):
    rclpy.init(args=args)
    node = Autodrive2Vehicle()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()

