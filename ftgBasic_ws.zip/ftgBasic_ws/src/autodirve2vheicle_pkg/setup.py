from setuptools import find_packages, setup

package_name = 'autodirve2vheicle_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='poliposition',
    maintainer_email='poliposition@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'autodirve2vheicle_node = autodirve2vheicle_pkg.autodirve2vheicle_node:main'
        ],
    },
)
